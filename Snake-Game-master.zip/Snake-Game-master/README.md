# Snake-Game
The traditional Snake Game.

## Screenshot
![Snake Game](https://github.com/alisolanki/Snake-Game/blob/master/snakegame.jpg)

## Author
* Mohd. Ali Solanki (https://www.alisolanki.gq)
